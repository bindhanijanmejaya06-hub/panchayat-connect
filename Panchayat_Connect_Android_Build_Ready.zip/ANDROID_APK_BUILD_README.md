# Panchayat Connect — Android APK build (phone-only workflow)

This repository is configured to build a **debug APK** automatically using GitHub Actions.
No Android Studio or laptop is needed for the cloud build.

## Build steps
1. Create a GitHub repository and upload the contents of this ZIP.
2. Ensure `.github/workflows/android-apk.yml` is present on the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Panchayat Connect Android APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, find **Artifacts**, and download `Panchayat-Connect-debug-apk`.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` on your Android phone to install it.
   If Android asks, allow your browser/file manager to install unknown apps.

## Important app/backend note
The APK packages the `www/` frontend. Your app's screen can open, but cloud data features require a configured Supabase project.
Open the app's cloud/Supabase settings and enter your Supabase Project URL and **anon public key**. Never put a Supabase `service_role` key in the app.
Configure the tables and Row Level Security policies safely before using real residents' data.
The included `server.js` is a separate Node/SQLite backend; it does not run inside the Android APK. It needs separate hosting if you intend to use that backend instead.

This workflow creates a debug APK for testing, not a Play Store release. A release APK/AAB should be signed with a private upload key and proper production security configuration.
