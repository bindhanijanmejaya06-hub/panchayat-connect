const express = require('express');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Initialize SQLite database
const db = new Database(path.join(__dirname, 'panchayat.db'));
const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
db.exec(schema);

// --- ISSUES API ---
app.get('/api/issues', (req, res) => {
  const rows = db.prepare('SELECT * FROM panchayat_issues ORDER BY rowid DESC').all();
  res.json(rows);
});

app.post('/api/issues', (req, res) => {
  const { id, state, district, block, panchayat, ward, resident_name, category, title, description, created_at } = req.body;
  db.prepare(`
    INSERT INTO panchayat_issues (id, state, district, block, panchayat, ward, resident_name, category, title, description, status, official_reply, upvotes, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', '', 1, ?)
  `).run(id, state, district, block, panchayat, ward, resident_name || '', category, title, description, created_at);
  res.status(201).json({ ok: true });
});

app.patch('/api/issues/:id', (req, res) => {
  const { status, official_reply, upvotes } = req.body;
  if (status !== undefined) {
    db.prepare('UPDATE panchayat_issues SET status = ? WHERE id = ?').run(status, req.params.id);
  }
  if (official_reply !== undefined) {
    db.prepare('UPDATE panchayat_issues SET official_reply = ? WHERE id = ?').run(official_reply, req.params.id);
  }
  if (upvotes !== undefined) {
    db.prepare('UPDATE panchayat_issues SET upvotes = ? WHERE id = ?').run(upvotes, req.params.id);
  }
  res.json({ ok: true });
});

app.delete('/api/issues/:id', (req, res) => {
  db.prepare('DELETE FROM panchayat_issues WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// --- UPDATES & SCHEMES API ---
app.get('/api/updates', (req, res) => {
  const rows = db.prepare('SELECT * FROM panchayat_updates ORDER BY rowid DESC').all();
  res.json(rows);
});

app.post('/api/updates', (req, res) => {
  const { id, panchayat, type, title, body, created_at } = req.body;
  db.prepare('INSERT INTO panchayat_updates (id, panchayat, type, title, body, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(id, panchayat, type, title, body, created_at);
  res.status(201).json({ ok: true });
});

app.delete('/api/updates/:id', (req, res) => {
  db.prepare('DELETE FROM panchayat_updates WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// --- CONTACTS API ---
app.get('/api/contacts', (req, res) => {
  const rows = db.prepare('SELECT * FROM panchayat_contacts ORDER BY rowid DESC').all();
  res.json(rows);
});

app.post('/api/contacts', (req, res) => {
  const { id, name, role, area, phone } = req.body;
  db.prepare('INSERT INTO panchayat_contacts (id, name, role, area, phone) VALUES (?, ?, ?, ?, ?)')
    .run(id, name, role, area, phone);
  res.status(201).json({ ok: true });
});

app.delete('/api/contacts/:id', (req, res) => {
  db.prepare('DELETE FROM panchayat_contacts WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Panchayat Connect running on http://localhost:${PORT}`);
});
