-- Database schema for Panchayat Connect (SQLite / PostgreSQL / Supabase compatible)

CREATE TABLE IF NOT EXISTS panchayat_issues (
  id TEXT PRIMARY KEY,
  state TEXT NOT NULL,
  district TEXT NOT NULL,
  block TEXT NOT NULL,
  panchayat TEXT NOT NULL,
  ward TEXT NOT NULL,
  resident_name TEXT DEFAULT '',
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT DEFAULT 'Open',
  official_reply TEXT DEFAULT '',
  upvotes INTEGER DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS panchayat_updates (
  id TEXT PRIMARY KEY,
  panchayat TEXT NOT NULL,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS panchayat_contacts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  area TEXT NOT NULL,
  phone TEXT NOT NULL
);
