# Panchayat Connect — Install & Publish Guide

## 1. Install Immediately on Phone (PWA)
1. Host the `www/` folder on any free HTTPS host (Netlify, Vercel, or GitHub Pages).
2. Open the link in Chrome (Android) or Safari (iPhone).
3. Tap **Add to Home Screen / Install App** — it installs with its own icon and works offline!

## 2. Build Android App (.apk / .aab) for Google Play Store
1. Install **Node.js** and **Android Studio** on your computer.
2. Open a terminal in this folder and run:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. In Android Studio:
   - Click **Run** to test on your Android phone.
   - Click **Build > Generate Signed Bundle / APK** to create the `.aab` file for Google Play Console.

## 3. Build iOS App for Apple App Store (Requires Mac + Xcode)
1. On a Mac with **Xcode** installed, run:
   ```bash
   npx cap add ios
   npx cap sync ios
   npx cap open ios
   ```
2. In Xcode, select your Apple Developer Team and click **Product > Archive** to upload to App Store Connect.
